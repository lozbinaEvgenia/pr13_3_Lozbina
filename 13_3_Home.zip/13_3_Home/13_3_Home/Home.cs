﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13_3_Home
{
    internal class Home
    {
        private string street;
        private int etag;
        private int countk;
        private double kvm;
        private int countg;
        public void Set(string street, int etag, int countk,double kvm,int countg)
        {
            this.street = street;
            this.etag = etag;
            this.countk = countk;
            this.kvm = kvm;
            this.countg = countg;
        }
        public string Street()
        {
            return street;
        }
        public int Etag()
        {
            return etag;
        }
        public int Countk()
        {
            return countk;
        }
        public double KVM()
        {
            return kvm;
        }
        public int Countg()
        {
            return countg;
        }

    }
}
